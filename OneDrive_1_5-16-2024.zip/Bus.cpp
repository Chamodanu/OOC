// IT22002174 DINETH T.H.V.
// Y1S2_2023_MTR_G10

#include <iostream>
#include <cstring>
#include "Bus.h"
using namespace std;

Bus::Bus() // Default Constructor
{
	BusID = "";
	BusRoute = "";

}
void Bus::setBusDetails(string bBusID, string bBusRoute)
{
	BusID = bBusID;
	BusRoute = bBusRoute;
}
void Bus::displayBusDetails()
{
}
void Bus::AddDriver(Driver* d1) {

}
Bus::~Bus() // Destructor 
{

}