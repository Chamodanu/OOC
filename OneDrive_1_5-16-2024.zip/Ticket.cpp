// IT22349460 WARUNIKA R.S.
// Y1S2_2023_MTR_G10

#include <iostream>
#include <cstring>
#include "Ticket.h"
using namespace std;

Ticket::Ticket() //Default Constructor
{

}
void Ticket::setTicketDetails(string tTicketID,int tRouteNo,string tRoute,double tTicketPrice)
{
	TicketID = tTicketID;
	RouteNo = tRouteNo;
	Route = tRoute;
	TicketPrice = tTicketPrice;
}
void Ticket::displayTicketDetails()
{

}
void Ticket::addBooking()
{
	booking[0] = new Booking();
	booking[1] = new Booking();
	booking[2] = new Booking();
}
void Ticket::addPayment()
{
	payment[0] = new Payment();
	payment[1] = new Payment();
	payment[2] = new Payment();
}
Ticket::~Ticket() //Destructor
{

}
