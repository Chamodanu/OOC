// IT22002174 DINETH T.H.V.
// Y1S2_2023_MTR_G10

#include <iostream>
#include "Driver.h"
#include "Bus.h"
#include "BusSchedule.h"

Driver::Driver() // Default Constructor 
{

}
void Driver::setDriver(string dDriverID,string dDriverName,string dLicenseNo)
{
	DriverID = dDriverID;
	DriverName = dDriverName;
	LicenseNo = dLicenseNo;
}
void Driver::displayDriverDetails()
{

}
void Driver::checkBusRoutes()
{

}
void Driver::AddSchedule(BusSchedule* schedule)
{

}
Driver::~Driver() //Destructor
{

}