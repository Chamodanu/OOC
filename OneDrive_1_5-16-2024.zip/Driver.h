// IT22002174 DINETH T.H.V.
// Y1S2_2023_MTR_G10

//Driver class

#include <iostream>
#include <cstring>
#include "GuestUser.h"
#include "Bus.h"
#include "BusSchedule.h"
#define SIZE 100
using namespace std;

class Driver :public GuestUser
{
protected:
	string DriverID;
	string DriverName;
	string LicenseNo;
	Bus* bus;
	BusSchedule* schedule[SIZE];

public:
	Driver(); // Default Constructor
	void setDriver(string dDriverID,string dDriverName,string dLicenseNo);
	void displayDriverDetails();
	void checkBusRoutes();
	void AddSchedule(BusSchedule* schedule);
	~Driver(); // Destructor
};