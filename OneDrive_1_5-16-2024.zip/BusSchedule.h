// IT22909428 NISFA N.M.F.
// Y1S2_2023_MTR_G10

//BusSchedule class

#include <iostream>
#include <cstring>
#include "Bus.h"
#include "Booking.h"
#define SIZE 100
using namespace std;

class BusSchedule {
private:
	string ScheduleID;
	string Route;
	string Date;
	double Fare;
	Driver driver[SIZE];
	Booking* booking[SIZE]; // composition relationship

public:
	BusSchedule(); // Default Constructor
	void setBusSchedule(string bScheduleID, string bRoute, string bDate, double Fare);
	void addBus(int qty, Bus* B);
	void AddDriver(Driver* driver);
	void displayBusSchedule();
	void Routes(string bRoute);
	void addBooking();
	~BusSchedule(); // Destructor
};