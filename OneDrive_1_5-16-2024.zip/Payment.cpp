// IT22352026 HANSARA K.D.K.U.
// Y1S2_2023_MTR_G10

#include <iostream>
#include "Payment.h"
using namespace std;

Payment::Payment() //Default Constructor
{

}
void Payment::setPaymentDetails(string pPaymentID, string pPaymentType, string
								pCardHolderName, string pCardNo, double pPaymentAmount)
{
	PaymentID = pPaymentID;
	PaymentType = pPaymentType;
	CardHolderName = pCardHolderName;
	CardNo = pCardNo;
	PaymentAmount = pPaymentAmount;
}
void Payment::displayPaymentDetails()
{

}
Payment::~Payment() //Destructor
{

}