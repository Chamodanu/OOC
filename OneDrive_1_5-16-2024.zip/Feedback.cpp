// IT22909428 NISFA N.M.F.
// Y1S2_2023_MTR_G10

#include <iostream>
#include <cstring>
#include "Feedback.h"
using namespace std;

Feedback::Feedback() //Default Constructor
{
	FeedbackID = 0;
	Message = "";
}
void Feedback::setFeedback(int fFeedbackID,string fMessage)
{
	FeedbackID = fFeedbackID;
	Message = fMessage;
}
void Feedback::displayFeedback()
{
}
Feedback::~Feedback() //Destructor
{
}