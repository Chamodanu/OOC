// IT22002174 DINETH T.H.V.
// Y1S2_2023_MTR_G10

//Bus class

#include <iostream>
#include <cstring>
#include "Driver.h"
#define SIZE 100
using namespace std;

class Bus
{
private:
	string BusID;
	string BusRoute;
	Driver* driver[SIZE];

public:
	Bus(); // Default Constructor
	void setBusDetails(string bBusID,string bBusRoute);
	void displayBusDetails();
	void AddDriver(Driver* driver);
	~Bus(); // Destructor
};
