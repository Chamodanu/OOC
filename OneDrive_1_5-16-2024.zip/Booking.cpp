// IT22352026 HANSARA K.D.K.U.
// Y1S2_2023_MTR_G10

#include <iostream>
#include "Booking.h"
#include "BusSchedule.h"
using namespace std;

Booking::Booking() // Default Constructor
{

}
void Booking::setBookingDetails(string bBookingID,int bSeatNo[],string bBookingDate,
								string bDepartureTime,string bArrivalTime,double bBookingAmount)
{
	int i;
	BookingID = bBookingID;
	SeatNo[30] = bSeatNo[i];
	BookingDate = bBookingDate;
	DepartureTime = bDepartureTime;
	ArrivalTime = bArrivalTime;
	BookingAmount = bBookingAmount;
}
double Booking::calcBookingprice(BusSchedule bRoute)
{
	double price = 0;
	int size = *(&SeatNo + 1) - SeatNo; //calculating number of seats

	//price of one seat in relevent route
	if (bRoute, "Matara-Kaduwela")
	{
		price = 990.0;
	}
	else if (bRoute, "Colombo-Matara")
	{
		price = 1020.0;
	}
	else if (bRoute, "Kadawatha-Galle")
	{
		price = 840.0;
	}
	else if (bRoute, "Colombo-Deniyaya")
	{
		price = 1290.0;
	}
	else if (bRoute, "Panadura-Matara")
	{
		price = 890.0;
	}
	else {
		return 0.0;
	}
	BookingAmount = price * size;
	return BookingAmount;
}
void Booking::displayBooking()
{

}
void Booking::addPayment()
{
	payment[0] = new Payment();
	payment[1] = new Payment();
	payment[2] = new Payment();
}
Booking::~Booking() //Destructor
{

}