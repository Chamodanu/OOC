// IT22352026 HANSARA K.D.K.U.
// Y1S2_2023_MTR_G10

//Payment class

#include <iostream>
using namespace std;

class Payment 
{
private:
	string PaymentID;
	string PaymentType;
	string CardHolderName;
	string CardNo;
	double PaymentAmount;

public:
	Payment(); // Default Constructor
	void setPaymentDetails(string pPaymentID,string pPaymentType,string
							pCardHolderName,string pCardNo,double pPaymentAmount);
	void displayPaymentDetails();
	~Payment(); // Destructor
};
