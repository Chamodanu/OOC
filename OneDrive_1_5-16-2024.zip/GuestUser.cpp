//IT22315496 ANURADHA D.P.G.C.
// Y1S2_2023_MTR_G10

#include <iostream>
#include "GuestUser.h"
using namespace std;


GuestUser::GuestUser() //Default Constructor
{
}
void GuestUser::setUserDetails(string gUserID,string gUserName,string gUserType,
								string gUserAddress,string gUserEmail,string gUserContactNo)
{
	userID = gUserID;
	userName = gUserName;
	userType = gUserType;
	userAddress = gUserAddress;
	userEmail = gUserEmail;
	userContactNo = gUserContactNo;
}
void GuestUser::displayUserDetails()
{

}
void GuestUser::checkBusSchedule()
{

}
GuestUser::~GuestUser() //Destructor
{

}