// IT22349460 WARUNIKA R.S.
// Y1S2_2023_MTR_G10

#include <iostream>
#include "Report.h"
using namespace std;

Report::Report() //Default Constructor
{

}
void Report::BookingDetailsReport()
{

}
void Report::TicketDetailsReport()
{

}
void Report::PaymentDetailsReport()
{

}
Report::~Report() //Destructor
{

}
