//IT22315496 ANURADHA D.P.G.C.
// Y1S2_2023_MTR_G10

#include <iostream>
#include "RegisteredUser.h"
using namespace std;


RegisteredUser::RegisteredUser() // Default Constructor
{

}
void RegisteredUser::login()
{

}
void RegisteredUser::setDetails(string rUserName,string rUserPassword)
{
	userName = rUserName;
	userPassword = rUserPassword;
}
void RegisteredUser::displayDetails()
{

}
void RegisteredUser::addFeedback(Feedback* F1,Feedback* F2,Feedback* F3)
{
	feedback[0] = F1;
	feedback[1] = F2;
	feedback[2] = F3;
}
void RegisteredUser::addBooking()
{
	booking[0] = new Booking();
	booking[1] = new Booking();
	booking[2] = new Booking();
}
void RegisteredUser::addTicket()
{
	ticket[0] = new Ticket();
	ticket[1] = new Ticket();
	ticket[2] = new Ticket();
}
void RegisteredUser::addPayment()
{
	payment[0] = new Payment();
	payment[1] = new Payment();
	payment[2] = new Payment();
}
void RegisteredUser::logout()
{

}
RegisteredUser::~RegisteredUser() // Destructor 
{

}