// IT22909428 NISFA N.M.F.
// Y1S2_2023_MTR_G10

#include <iostream>
#include <cstring>
#include "BusSchedule.h"
using namespace std;

BusSchedule::BusSchedule() //Default Constructor
{
	ScheduleID = "";
	Route = "";
	Date = "";
	Fare = 0.0;
}
void BusSchedule::setBusSchedule(string bScheduleID, string bRoute, string bDate, double bFare)
{
	ScheduleID = bScheduleID;
	Route = bRoute;
	Date = bDate;
	Fare = bFare;
}
void BusSchedule::addBus(int qty, Bus* B)
{
	Fare = qty * B->displayBusDetails();
}
void BusSchedule::AddDriver(Driver* driver)
{

}
void BusSchedule::displayBusSchedule()
{

}
void BusSchedule::Routes(string bRoute)
{

}
void BusSchedule::addBooking()
{
	booking[0] = new Booking();
	booking[1] = new Booking();
	booking[2] = new Booking();
}
BusSchedule::~BusSchedule() //Destructor
{

}
