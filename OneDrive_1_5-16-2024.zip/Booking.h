// IT22352026 HANSARA K.D.K.U.
// Y1S2_2023_MTR_G10

//Booking class

#include <iostream>
#include "BusSchedule.h"
#include "Payment.h"
#define SIZE 30
using namespace std;

class Booking
{
private:
	string BookingID;
	int SeatNo[30];
	string BookingDate;
	string DepartureTime;
	string ArrivalTime;
	double BookingAmount;
	Payment* payment[SIZE]; // composition relationship

public:
	Booking(); // Default Constructor
	void setBookingDetails(string bBookingID,int bSeatNo[],string bBookingDate,
							string bDepartureTime,string bArrivalTime,double bBookingAmount);
	double calcBookingprice(BusSchedule bRoute);
	void displayBooking();
	void addPayment();
	~Booking(); // Destructor
};