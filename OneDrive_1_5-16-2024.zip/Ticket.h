// IT22349460 WARUNIKA R.S.
// Y1S2_2023_MTR_G10

// Ticket Class

#include <iostream>
#include <cstring>
#include "Payment.h"
#include "Booking.h"
#define SIZE 20
using namespace std;

class Ticket {
private:
	string TicketID;
	int RouteNo;
	string Route;
	double TicketPrice;
	Booking* booking[SIZE]; // composition relationship
	Payment* payment[SIZE]; // composition relationship

public:
	Ticket(); // Default Constructor
	void setTicketDetails(string tTicketID, int tRouteNo, string tRoute, double tTicketPrice);
	void displayTicketDetails();
	void addBooking();
	void addPayment();
	~Ticket(); // Destructor
};