//IT22315496 ANURADHA D.P.G.C.
// Y1S2_2023_MTR_G10

// GuestUser class

#include <iostream>
#include <cstring>
using namespace std;

class GuestUser
{
protected:
	string userID;
	string userName;
	string userType;
	string userAddress;
	string userEmail;
	string userContactNo;

public:
	GuestUser(); // Default Constructor
	void setUserDetails(string gUserID,string gUserName,string gUserType,
						string gUserAddress,string gUserEmail,string gUserContactNo);
	void displayUserDetails();
	void checkBusSchedule();
	~GuestUser(); // Destructor
};
