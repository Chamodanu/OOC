// IT22349460 WARUNIKA R.S.
// Y1S2_2023_MTR_G10

//Report class

#include "Ticket.h"
#include "Payment.h"
#include "Booking.h"
#define SIZE 20
using namespace std;

class Report
{
private:
	string ReportID;
	string IssueDate;
	Ticket* ticket[SIZE]; // uni-directional relationship
	Payment* payment[SIZE]; // uni-directional relationship
	Booking* booking[SIZE]; // uni-directional relationship

public:
	Report(); // Default Constructor
	void BookingDetailsReport();
	void TicketDetailsReport();
	void PaymentDetailsReport();
	~Report(); // Destructor
};