// IT22909428 NISFA N.M.F.
// Y1S2_2023_MTR_G10

//Feedback class

#include <iostream>
#include <cstring>
using namespace std;

class Feedback
{
private:
	int FeedbackID;
	string Message;

public:
	Feedback(); // Default Constructor
	void setFeedback(int fFeedbackID,string fMessage);
	void displayFeedback();
	~Feedback(); // Destructor
};
