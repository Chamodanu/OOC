//IT22315496 ANURADHA D.P.G.C.
// Y1S2_2023_MTR_G10

// RegisteredUser class

#include <iostream>
#include <cstring>
#include "GuestUser.h"
#include "Ticket.h"
#include "Payment.h"
#include "Booking.h"
#include "Feedback.h"
#define SIZE 30
using namespace std;

class RegisteredUser : public GuestUser //Inheritance Relationship
{
protected:
	string userName;
	string userPassword;
	Feedback* feedback[SIZE]; //Aggregation Relationship
	Ticket* ticket[SIZE]; //Composition Relationship
	Booking* booking[SIZE]; //Composition Relationship 
	Payment* payment[SIZE]; //Composition Relationship
	
public:
	RegisteredUser(); // Default Constructor
	void login();
	void setDetails(string rUserName,string rUserPassword);
	void displayDetails();
	void addFeedback(Feedback* F1,Feedback* F2,Feedback* F3);
	void addTicket();
	void addBooking();
	void addPayment();
	void logout();
	~RegisteredUser(); // Destructor
};
